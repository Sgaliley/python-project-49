### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sgaliley/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sgaliley/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b9a35673e6737e98d91c/maintainability)](https://codeclimate.com/github/Sgaliley/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/b9a35673e6737e98d91c/test_coverage)](https://codeclimate.com/github/Sgaliley/python-project-49/test_coverage)