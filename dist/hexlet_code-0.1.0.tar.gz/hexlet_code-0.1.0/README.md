### Hexlet tests and linter status:
[![Actions Status](https://github.com/Sgaliley/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Sgaliley/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/b9a35673e6737e98d91c/maintainability)](https://codeclimate.com/github/Sgaliley/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/b9a35673e6737e98d91c/test_coverage)](https://codeclimate.com/github/Sgaliley/python-project-49/test_coverage)

### Демонстрация Brain-even

Посмотрите [аскинему](<https://asciinema.org/a/mtz0Zvfw1gZZs42pcjvkVZqDX>) запуск и игровой процесс.

### Демонстрация Brain-calc

Посмотрите [аскинему](<https://asciinema.org/a/vWbmQlXDotR4ONf4kkmdmZ1x1>) запуск и игровой процесс.

### Демонстрация Brain-gcd

Посмотрите [аскинему](<https://asciinema.org/a/yDfhF8In06y1AnmydJyvFZzVA>) запуск и игровой процесс.

### Демонстрация Brain-progression

Посмотрите [аскинему](<https://asciinema.org/a/UDgDpIFlfsInJW20pLBi82btt>) запуск и игровой процесс.

### Демонстрация Brain-prime

Посмотрите [аскинему](<https://asciinema.org/a/Bci8VT8Qasptl7qb9GMMDDhLi>) запуск и игровой процесс.