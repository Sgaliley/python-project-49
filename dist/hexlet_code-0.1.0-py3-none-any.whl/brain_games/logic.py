import random


def num_random():
    num = random.randint(1, 10)
    return num
